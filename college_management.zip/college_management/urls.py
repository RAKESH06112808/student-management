from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path, include
from student.views import CustomLoginView


urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("student.urls")),

    path(
        "accounts/login/",
        CustomLoginView.as_view(
            template_name="registration/login.html"
        ),
        name="login",
    ),

    path(
        "accounts/logout/",
        auth_views.LogoutView.as_view(),
        name="logout",
    ),
]